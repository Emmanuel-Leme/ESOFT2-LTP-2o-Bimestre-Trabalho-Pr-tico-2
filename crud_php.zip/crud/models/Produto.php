<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Model de Produtos - acesso ao banco de dados
*******************************************************************************/

class Produto {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Lista os produtos já trazendo o nome da categoria (JOIN)
    public function listar() {
        $sql = "SELECT p.*, c.nome AS categoria_nome
                FROM produtos p
                INNER JOIN categorias c ON c.id = p.categoria_id
                ORDER BY p.nome";
        return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscar($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM produtos WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function criar($nome, $preco, $estoque, $categoria_id) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO produtos (nome, preco, estoque, categoria_id) VALUES (?, ?, ?, ?)"
        );
        return $stmt->execute([$nome, $preco, $estoque, $categoria_id]);
    }

    public function atualizar($id, $nome, $preco, $estoque, $categoria_id) {
        $stmt = $this->pdo->prepare(
            "UPDATE produtos SET nome = ?, preco = ?, estoque = ?, categoria_id = ? WHERE id = ?"
        );
        return $stmt->execute([$nome, $preco, $estoque, $categoria_id, $id]);
    }

    public function excluir($id) {
        $stmt = $this->pdo->prepare("DELETE FROM produtos WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
