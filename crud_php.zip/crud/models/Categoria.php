<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Model de Categorias - acesso ao banco de dados
*******************************************************************************/

class Categoria {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Retorna todas as categorias
    public function listar() {
        $stmt = $this->pdo->query("SELECT * FROM categorias ORDER BY nome");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Busca uma categoria pelo id
    public function buscar($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM categorias WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Insere uma nova categoria
    public function criar($nome, $descricao) {
        $stmt = $this->pdo->prepare("INSERT INTO categorias (nome, descricao) VALUES (?, ?)");
        return $stmt->execute([$nome, $descricao]);
    }

    // Atualiza uma categoria existente
    public function atualizar($id, $nome, $descricao) {
        $stmt = $this->pdo->prepare("UPDATE categorias SET nome = ?, descricao = ? WHERE id = ?");
        return $stmt->execute([$nome, $descricao, $id]);
    }

    // Exclui uma categoria
    public function excluir($id) {
        $stmt = $this->pdo->prepare("DELETE FROM categorias WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
