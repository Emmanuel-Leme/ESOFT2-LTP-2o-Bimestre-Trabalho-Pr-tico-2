<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Parte superior do layout (menu e mensagens)
*/ ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema CRUD - Produtos e Categorias</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <h1>Sistema de Produtos</h1>
    <nav>
        <a href="index.php?pagina=produtos" class="<?= $pagina === 'produtos' ? 'ativo' : '' ?>">Produtos</a>
        <a href="index.php?pagina=categorias" class="<?= $pagina === 'categorias' ? 'ativo' : '' ?>">Categorias</a>
    </nav>
</header>
<main>
<?php if (isset($_GET['msg'])): ?>
    <div class="mensagem"><?= htmlspecialchars($_GET['msg']) ?></div>
<?php endif; ?>
