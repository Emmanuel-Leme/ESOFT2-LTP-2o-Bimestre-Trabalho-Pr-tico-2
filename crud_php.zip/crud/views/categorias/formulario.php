<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: View - formulário de categoria (novo ou edição)
*/ ?>
<h2><?= $categoria ? 'Editar categoria' : 'Nova categoria' ?></h2>

<?php if ($erro): ?>
    <div class="erro"><?= $erro ?></div>
<?php endif; ?>

<form method="post" action="index.php?pagina=categorias&acao=formulario">
    <input type="hidden" name="id" value="<?= $categoria['id'] ?? '' ?>">

    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" maxlength="100"
           value="<?= htmlspecialchars($categoria['nome'] ?? '') ?>" required>

    <label for="descricao">Descrição</label>
    <textarea id="descricao" name="descricao" rows="4"><?= htmlspecialchars($categoria['descricao'] ?? '') ?></textarea>

    <button type="submit" class="btn btn-novo">Salvar</button>
    <a class="btn btn-cancelar" href="index.php?pagina=categorias">Cancelar</a>
</form>
