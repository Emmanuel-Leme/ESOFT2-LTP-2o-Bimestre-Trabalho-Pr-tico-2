<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: View - listagem de categorias
*/ ?>
<div class="titulo-pagina">
    <h2>Categorias</h2>
    <a class="btn btn-novo" href="index.php?pagina=categorias&acao=formulario">+ Nova categoria</a>
</div>

<table>
    <thead>
        <tr><th>ID</th><th>Nome</th><th>Descrição</th><th>Ações</th></tr>
    </thead>
    <tbody>
    <?php if (count($categorias) === 0): ?>
        <tr><td colspan="4">Nenhuma categoria cadastrada.</td></tr>
    <?php endif; ?>
    <?php foreach ($categorias as $c): ?>
        <tr>
            <td><?= $c['id'] ?></td>
            <td><?= htmlspecialchars($c['nome']) ?></td>
            <td><?= htmlspecialchars($c['descricao']) ?></td>
            <td>
                <a class="btn btn-editar" href="index.php?pagina=categorias&acao=formulario&id=<?= $c['id'] ?>">Editar</a>
                <a class="btn btn-excluir" href="index.php?pagina=categorias&acao=excluir&id=<?= $c['id'] ?>"
                   onclick="return confirm('Deseja excluir esta categoria?')">Excluir</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
