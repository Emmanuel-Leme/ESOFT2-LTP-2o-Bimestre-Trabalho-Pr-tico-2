<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Parte inferior do layout
*/ ?>
</main>
<footer>
    <p>Engenharia de Software - Linguagem e Técnicas de Programação</p>
</footer>
</body>
</html>
