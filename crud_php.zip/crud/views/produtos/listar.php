<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: View - listagem de produtos
*/ ?>
<div class="titulo-pagina">
    <h2>Produtos</h2>
    <a class="btn btn-novo" href="index.php?pagina=produtos&acao=formulario">+ Novo produto</a>
</div>

<table>
    <thead>
        <tr><th>ID</th><th>Nome</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Ações</th></tr>
    </thead>
    <tbody>
    <?php if (count($produtos) === 0): ?>
        <tr><td colspan="6">Nenhum produto cadastrado.</td></tr>
    <?php endif; ?>
    <?php foreach ($produtos as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['nome']) ?></td>
            <td><?= htmlspecialchars($p['categoria_nome']) ?></td>
            <td>R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
            <td><?= $p['estoque'] ?></td>
            <td>
                <a class="btn btn-editar" href="index.php?pagina=produtos&acao=formulario&id=<?= $p['id'] ?>">Editar</a>
                <a class="btn btn-excluir" href="index.php?pagina=produtos&acao=excluir&id=<?= $p['id'] ?>"
                   onclick="return confirm('Deseja excluir este produto?')">Excluir</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
