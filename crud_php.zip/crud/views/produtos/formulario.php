<?php /*
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: View - formulário de produto (novo ou edição)
*/ ?>
<h2><?= $produto ? 'Editar produto' : 'Novo produto' ?></h2>

<?php if ($erro): ?>
    <div class="erro"><?= $erro ?></div>
<?php endif; ?>

<form method="post" action="index.php?pagina=produtos&acao=formulario">
    <input type="hidden" name="id" value="<?= $produto['id'] ?? '' ?>">

    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" maxlength="100"
           value="<?= htmlspecialchars($produto['nome'] ?? '') ?>" required>

    <label for="preco">Preço (R$)</label>
    <input type="number" id="preco" name="preco" step="0.01" min="0"
           value="<?= $produto['preco'] ?? '' ?>" required>

    <label for="estoque">Estoque</label>
    <input type="number" id="estoque" name="estoque" min="0"
           value="<?= $produto['estoque'] ?? 0 ?>" required>

    <label for="categoria_id">Categoria</label>
    <select id="categoria_id" name="categoria_id" required>
        <option value="">Selecione...</option>
        <?php foreach ($categorias as $c): ?>
            <option value="<?= $c['id'] ?>"
                <?= (isset($produto['categoria_id']) && $produto['categoria_id'] == $c['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['nome']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit" class="btn btn-novo">Salvar</button>
    <a class="btn btn-cancelar" href="index.php?pagina=produtos">Cancelar</a>
</form>
