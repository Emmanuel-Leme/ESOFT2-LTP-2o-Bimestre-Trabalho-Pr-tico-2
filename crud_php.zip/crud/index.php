<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Front controller - direciona as requisições para os controllers
*******************************************************************************/

require_once 'config/database.php';
require_once 'models/Categoria.php';
require_once 'models/Produto.php';
require_once 'controllers/CategoriaController.php';
require_once 'controllers/ProdutoController.php';

$pdo = conectar();

// Parâmetros da URL: ?pagina=produtos&acao=listar
$pagina = $_GET['pagina'] ?? 'produtos';
$acao = $_GET['acao'] ?? 'listar';

// Escolhe o controller conforme a página
if ($pagina === 'categorias') {
    $controller = new CategoriaController($pdo);
} else {
    $pagina = 'produtos';
    $controller = new ProdutoController($pdo);
}

// Só permite as ações previstas
if (!in_array($acao, ['listar', 'formulario', 'excluir'])) {
    $acao = 'listar';
}

include 'views/topo.php';
$controller->$acao();
include 'views/rodape.php';
