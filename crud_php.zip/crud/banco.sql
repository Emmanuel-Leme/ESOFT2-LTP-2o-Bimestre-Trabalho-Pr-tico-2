-- Script de criação do banco de dados do sistema CRUD
CREATE DATABASE IF NOT EXISTS loja_crud CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE loja_crud;

CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT
);

CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    categoria_id INT NOT NULL,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Dados de exemplo
INSERT INTO categorias (nome, descricao) VALUES
('Eletrônicos', 'Aparelhos e acessórios eletrônicos'),
('Livros', 'Livros técnicos e literatura'),
('Papelaria', 'Material de escritório e escolar');

INSERT INTO produtos (nome, preco, estoque, categoria_id) VALUES
('Mouse sem fio', 59.90, 25, 1),
('Teclado mecânico', 249.00, 10, 1),
('Clean Code', 89.90, 8, 2),
('Caderno universitário', 18.50, 60, 3);
