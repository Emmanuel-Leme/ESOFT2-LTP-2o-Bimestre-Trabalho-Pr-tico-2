<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Configuração e conexão com o banco de dados MySQL (PDO)
*******************************************************************************/

// Dados de conexão (ajuste conforme o seu ambiente)
define('DB_HOST', 'localhost');
define('DB_NAME', 'loja_crud');
define('DB_USER', 'root');
define('DB_PASS', '');

// Retorna um objeto PDO conectado ao banco
function conectar() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS
        );
        // Faz o PDO lançar exceções quando houver erro de SQL
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro ao conectar no banco: " . $e->getMessage());
    }
}
