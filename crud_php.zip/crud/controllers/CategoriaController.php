<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Controller de Categorias - lógica de negócio
*******************************************************************************/

class CategoriaController {
    private $model;

    public function __construct($pdo) {
        $this->model = new Categoria($pdo);
    }

    // Tela de listagem
    public function listar() {
        $categorias = $this->model->listar();
        include 'views/categorias/listar.php';
    }

    // Formulário (novo ou edição) e gravação
    public function formulario() {
        $categoria = null;
        $erro = '';

        // Se veio id na URL, é edição: carrega os dados
        if (isset($_GET['id'])) {
            $categoria = $this->model->buscar((int) $_GET['id']);
        }

        // Se o formulário foi enviado, valida e grava
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? '';
            $nome = trim($_POST['nome']);
            $descricao = trim($_POST['descricao']);

            if ($nome === '') {
                $erro = 'O nome da categoria é obrigatório.';
                $categoria = ['id' => $id, 'nome' => $nome, 'descricao' => $descricao];
            } else {
                if ($id === '') {
                    $this->model->criar($nome, $descricao);
                    $msg = 'Categoria cadastrada com sucesso!';
                } else {
                    $this->model->atualizar($id, $nome, $descricao);
                    $msg = 'Categoria atualizada com sucesso!';
                }
                header('Location: index.php?pagina=categorias&msg=' . urlencode($msg));
                exit;
            }
        }
        include 'views/categorias/formulario.php';
    }

    // Exclusão (não permite se existirem produtos vinculados)
    public function excluir() {
        try {
            $this->model->excluir((int) $_GET['id']);
            $msg = 'Categoria excluída com sucesso!';
        } catch (PDOException $e) {
            $msg = 'Não foi possível excluir: existem produtos nesta categoria.';
        }
        header('Location: index.php?pagina=categorias&msg=' . urlencode($msg));
        exit;
    }
}
