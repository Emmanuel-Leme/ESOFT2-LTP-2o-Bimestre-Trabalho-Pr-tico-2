<?php
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Linguagem e Técnicas de Programação
Professor: Flores
Turma: ESOFT-2
Componentes:
 SEU_RA - SEU NOME COMPLETO
Data: DD de Novembro de 2025
Descritivo: Controller de Produtos - lógica de negócio
*******************************************************************************/

class ProdutoController {
    private $model;
    private $categoriaModel;

    public function __construct($pdo) {
        $this->model = new Produto($pdo);
        $this->categoriaModel = new Categoria($pdo);
    }

    public function listar() {
        $produtos = $this->model->listar();
        include 'views/produtos/listar.php';
    }

    public function formulario() {
        $produto = null;
        $erro = '';
        $categorias = $this->categoriaModel->listar(); // para o <select>

        if (isset($_GET['id'])) {
            $produto = $this->model->buscar((int) $_GET['id']);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? '';
            $nome = trim($_POST['nome']);
            $preco = str_replace(',', '.', $_POST['preco']);
            $estoque = (int) $_POST['estoque'];
            $categoria_id = (int) $_POST['categoria_id'];

            // Validações básicas
            if ($nome === '' || !is_numeric($preco) || $preco < 0 || $categoria_id === 0) {
                $erro = 'Preencha nome, preço (número válido) e categoria.';
                $produto = [
                    'id' => $id, 'nome' => $nome, 'preco' => $preco,
                    'estoque' => $estoque, 'categoria_id' => $categoria_id
                ];
            } else {
                if ($id === '') {
                    $this->model->criar($nome, $preco, $estoque, $categoria_id);
                    $msg = 'Produto cadastrado com sucesso!';
                } else {
                    $this->model->atualizar($id, $nome, $preco, $estoque, $categoria_id);
                    $msg = 'Produto atualizado com sucesso!';
                }
                header('Location: index.php?pagina=produtos&msg=' . urlencode($msg));
                exit;
            }
        }
        include 'views/produtos/formulario.php';
    }

    public function excluir() {
        $this->model->excluir((int) $_GET['id']);
        header('Location: index.php?pagina=produtos&msg=' . urlencode('Produto excluído com sucesso!'));
        exit;
    }
}
